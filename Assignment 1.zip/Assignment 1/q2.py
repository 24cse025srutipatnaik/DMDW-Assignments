t=(10,20,30,40,50)
print(t)
print(type(t))
for i in t:
    print(i)