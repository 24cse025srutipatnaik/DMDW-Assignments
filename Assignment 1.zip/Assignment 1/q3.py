d={"Ram":1,"Sam":2,"Sita":3}
print(d)
print(type(d))
for key,value in d.items():
    print(key,":",value)