s={10,20,30,40}
print(s)
for i in s:
    print(i)