x=int(input("Enter 1st no"))
y=int(input("Enter 2nd no"))
z=int(input("Enter 3rd no"))
def greatest(a,b,c):
    if a>=b and a>=c:
        return a
    if b>=a and b>=c:
        return b
    else:
        return c
print("The greatest no =", greatest(x,y,z))
