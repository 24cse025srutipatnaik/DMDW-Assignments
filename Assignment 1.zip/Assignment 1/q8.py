f1 = open("file1.txt", "w")
f1.write("Hello\n")
f1.write("Hi")
f1.close()

f1 = open("file1.txt", "r")
f2 = open("file3.txt", "w")

l = f1.read()
f2.write(l)

print("Content copied successfully")

f1.close()
f2.close()