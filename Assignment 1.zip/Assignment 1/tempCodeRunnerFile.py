f1.close()
f2.close()