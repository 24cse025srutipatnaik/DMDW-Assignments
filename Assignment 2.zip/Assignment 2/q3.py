data=[10,12,15,18,20,20,22,25]
f={}
for value in data:
    if value in f:
        f[value]+=1
    else:
        f[value]=1
mode=max(f,key=f.get)
print("Mode=",mode)


# wiithout methods
from statistics import mode
data=[10,12,15,18,20,20,22,25]
print(mode(data))