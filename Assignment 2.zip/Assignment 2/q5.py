import math
data=[10,12,15,18,20,20,22,25]
mean=sum(data)/len(data)
variance=0
for value in data:
    variance+=(value-mean)**2
variance=variance/len(data)
std=math.sqrt(variance)
print("Standard Deviation",std)

# with methods
import numpy as np
data=[10,12,15,18,20,20,22,25]
print(np.std(data))