def calculate_mean(data):
    return sum(data) / len(data)


def calculate_median(data):
    sorted_data = sorted(data)
    n = len(sorted_data)
    mid = n // 2

    if n % 2 == 0:
        median = (sorted_data[mid - 1] + sorted_data[mid]) / 2
    else:
        median = sorted_data[mid]

    return median


def calculate_mode(data):
    frequency = {}

    for num in data:
        frequency[num] = frequency.get(num, 0) + 1

    mode = max(frequency, key=frequency.get)
    return mode


def calculate_variance(data):
    mean = calculate_mean(data)
    variance = sum((x - mean) ** 2 for x in data) / len(data)
    return variance


def calculate_std_deviation(data):
    variance = calculate_variance(data)
    return variance ** 0.5


data = [int(x) for x in input("Enter a series of numbers: ").split()]

mean = calculate_mean(data)
median = calculate_median(data)
mode = calculate_mode(data)
variance = calculate_variance(data)
std_deviation = calculate_std_deviation(data)

print(f"Mean = {mean}")
print(f"Median = {median}")
print(f"Mode = {mode}")
print(f"Variance = {variance}")
print(f"Standard Deviation = {std_deviation}")