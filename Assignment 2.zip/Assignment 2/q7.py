import numpy as np
import statistics as stats

data=[10,15,20,25,30,35,40,45,50,55]

mean=np.mean(data)
print(f"Mean:{mean}")

median=np.median(data)
print(f"Median:{median}")

mode=stats.mode(data)
print(f"Mode{mode}")

std_dev=np.std(data)
print(f"Standard deviation{std_dev}")

variance=np.var(data)
print(f"variance{variance}")