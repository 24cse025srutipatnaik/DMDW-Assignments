import random as r
num=r.random()
print(num)

list=[10,20,30,40,50,60,70,80,90,100]
print(r.choice(list))

print(r.choice([1,2,3,4,5,6,7,8,9,10]))
print(r.randrange(10,50,3))

print(r.random())
r.seed(5)
print(r.random())